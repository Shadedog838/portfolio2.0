package puzzles.clock;

import puzzles.common.solver.Configuration;

import java.util.ArrayList;
import java.util.Collection;
/*
BY Shandon Mith
 */
public class ClockConfig implements Configuration {
    private static int hours;
    private static int start;
    private static int end;
    private int current;


//    creates a clockconfig contructor
    public ClockConfig(int hours, int start, int end) {
        ClockConfig.hours = hours;
        ClockConfig.start = start;
        ClockConfig.end = end;
        this.current = start;
    }

//    makes a copy of the clockconfig contructor
    public ClockConfig(int current) {
        this.current = current;
    }

//    determines possible moves for the puzzles
    @Override
    public Collection<Configuration> getNeighbors() {
        ArrayList<Configuration> neighbors = new ArrayList<>();
        if (current == 1) {
            ClockConfig clock1 = new ClockConfig(hours);
            ClockConfig clock2 = new ClockConfig(current + 1);
            neighbors.add(clock1);
            neighbors.add(clock2);
        } else if (current  == hours ) {
            ClockConfig clock1 = new ClockConfig(current-1 );
            ClockConfig clock2 = new ClockConfig(1);
            neighbors.add(clock1);
            neighbors.add(clock2);
        } else {
            ClockConfig clock1 = new ClockConfig(current - 1);
            ClockConfig clock2 = new ClockConfig(current + 1);
            neighbors.add(clock1);
            neighbors.add(clock2);
        }
        return neighbors;
    }

// compares two clockconfig objects
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof ClockConfig) {
            return  ((ClockConfig) obj).current  == current;
        }
        return false;
    }

//    give clockconfig object a hashcode
    @Override
    public int hashCode()
    {
        return this.current;
    }


//    determins if current clockconfig is the solution
    @Override
    public boolean isSolution() {
        return current == end;
    }

//    presents clockconfig as a string
    @Override
    public String toString() {
        return String.valueOf(current);
    }
}
