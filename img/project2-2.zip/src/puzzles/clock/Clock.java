package puzzles.clock;

import puzzles.common.solver.Solver;
import puzzles.common.solver.Configuration;

import java.util.ArrayList;
/*
BY Shandon Mith
 */

// Initializes clock puzzle and returns a path to the solution
public class Clock {
    public static void main(String[] args) {
        Solver solve = new Solver();
        if (args.length != 3) {
            System.out.println("Usage: java Clock hours start stop");
        } else {
            System.out.print("Hours: " + args[0] + "," );
            System.out.print(" Start: " + args[1] + "," );
            System.out.println(" End: " + args[2]);
            ClockConfig clockConfig = new ClockConfig(Integer.parseInt(args[0]),Integer.parseInt(args[1]),Integer.parseInt(args[2]));
            ArrayList<Configuration> path = solve.solve(clockConfig);
            System.out.println("Total configs: " + solve.getTotalConfigs());
            System.out.println("Unique configs: " + solve.getUniqueConfigs());
            if (path.isEmpty()) {
                System.out.println("No solution");
            } else {
                int step = 0;
                for (Configuration i : path) {
                    System.out.println("Step " + step + ": " + i.toString());
                    step += 1;
                }
            }
        }
    }


}
