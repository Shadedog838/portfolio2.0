package puzzles.common.solver;

import java.util.*;
/*
BY Shandon Mith
 */
public class Solver {
    int totalConfigs = 1;
    int uniqueConfigs = 1;
//  returns totalconfig
    public int getTotalConfigs() {
        return totalConfigs;
    }
// retruns uniqueconfigs
    public int getUniqueConfigs() {
        return uniqueConfigs;
    }

//    BFS
    public ArrayList<Configuration> solve(Configuration config) {
        Configuration current;
        Configuration end = null;
        List<Configuration> queue = new LinkedList<>();
        queue.add(config);
        Map<Configuration, Configuration> predecessor = new HashMap<>();
        predecessor.put(config, null);
        while (!queue.isEmpty()) {
            current = queue.remove(0);
            if (current.isSolution()) {
                end = current;
                break;
            }
            for (Configuration nbr : current.getNeighbors()) {
                totalConfigs += 1;
                if (!predecessor.containsKey(nbr)) {
                    predecessor.put(nbr, current);
                    uniqueConfigs += 1;
                    queue.add(nbr);
                }
            }
        }
        ArrayList<Configuration> path = new ArrayList<>();
        if (predecessor.containsKey(end)) {
            Configuration currNode = end;
            while (currNode != config) {
                path.add(0, currNode);
                currNode = predecessor.get(currNode);
            }
            path.add(0, config);
        }
        return path;
    }
}