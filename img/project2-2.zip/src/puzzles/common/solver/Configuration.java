package puzzles.common.solver;

import java.util.Collection;
/*
BY Shandon Mith
 */
public interface Configuration {

//    gets possible sollution to a puzzle
    Collection<Configuration> getNeighbors();

//    determins if current puzzle config is the solution
    boolean isSolution();
}
