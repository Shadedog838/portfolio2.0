package puzzles.jam.solver;

import puzzles.common.solver.Solver;

public class Jam {
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: java Jam filename");
        }
    }
}