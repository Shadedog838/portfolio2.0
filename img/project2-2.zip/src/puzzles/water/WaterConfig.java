package puzzles.water;

import puzzles.common.solver.Configuration;

import java.util.ArrayList;

import java.util.Collection;

public class WaterConfig implements Configuration {
    private static int amount;
    private static  ArrayList<Integer> buckets;
    private ArrayList<Integer> currentBuckets = new ArrayList<>();

    public WaterConfig(int amount, ArrayList<Integer> buckets)  {
        WaterConfig.amount = amount;
        WaterConfig.buckets = buckets;
        for (int i = 0; i < buckets.size(); ++i) {
            currentBuckets.add(0);
        }
    }

    public WaterConfig(ArrayList<Integer> currentBuckets) {
        this.currentBuckets = currentBuckets;
    }

    private ArrayList<Integer> makeDeepCopyInteger(ArrayList<Integer> old){
        ArrayList<Integer> copy = new ArrayList<>(old.size());
        copy.addAll(old);
        return copy;
    }


    @Override
    public Collection<Configuration> getNeighbors() {
        ArrayList<Configuration> neighbors = new ArrayList<>();
        for (int i=0; i< this.currentBuckets.size(); ++i) {
            ArrayList<Integer> newBuckets1 = makeDeepCopyInteger(this.currentBuckets);
            if (this.currentBuckets.get(i) != 0) {
                newBuckets1.set(i, 0);
                WaterConfig water1 = new WaterConfig(newBuckets1);
                neighbors.add(water1);
            }
            if (!this.currentBuckets.get(i).equals(buckets.get(i))) {
                ArrayList<Integer> newBuckets2 = makeDeepCopyInteger(this.currentBuckets);
                newBuckets2.set(i, buckets.get(i));
                WaterConfig water2 = new WaterConfig(newBuckets2);
                neighbors.add(water2);
            }
            for (int j=0; j < this.currentBuckets.size(); ++j) {
                if (i != j) {
                    ArrayList<Integer> newBuckets3 = makeDeepCopyInteger(this.currentBuckets);
                    int maxCapacityJ = buckets.get(j);
                    int currentI = this.currentBuckets.get(i);
                    int currentJ = this.currentBuckets.get(j);
                    if (currentI == 0 || (currentJ == maxCapacityJ)){
                        continue;
                    }
                    if (currentI <= (maxCapacityJ - currentJ)) {
                        newBuckets3.set(i, 0);
                        newBuckets3.set(j, currentJ + currentI);
                        WaterConfig water3 = new WaterConfig(newBuckets3);
                        neighbors.add(water3);
                    } else if (currentI > (maxCapacityJ - currentJ)) {
                        newBuckets3.set(i, currentI - (maxCapacityJ - currentJ));
                        newBuckets3.set(j, currentJ + (maxCapacityJ - currentJ));
                        WaterConfig water3 = new WaterConfig(newBuckets3);
                        neighbors.add(water3);
                    }
                }
            }



        }
        return neighbors;
    }

    @Override
    public boolean isSolution() {
        return currentBuckets.contains(amount);
    }

    @Override
    public boolean equals(Object obj) {
        ArrayList<Integer> list1 = new ArrayList<>();
        ArrayList<Integer> list2 = new ArrayList<>();
        if (obj instanceof WaterConfig) {
            list1 = this.currentBuckets;
            list2 = ((WaterConfig) obj).currentBuckets;
            return list1.equals(list2);
        }
        return  false;
    }

    @Override
    public int hashCode() {
        return this.currentBuckets.hashCode();
    }

    @Override
    public String toString() {
        StringBuilder myString = new StringBuilder();
        myString.append("[");
        for (int i=0; i < currentBuckets.size(); ++i) {
            if (i == currentBuckets.size()-1){
                myString.append(currentBuckets.get(i));
            } else {
                myString.append(currentBuckets.get(i)).append(", ");
            }
        }
        myString.append("]");
        return myString.toString();
    }
}
