package puzzles.water;

import puzzles.common.solver.Solver;
import puzzles.common.solver.Configuration;

import java.util.ArrayList;

public class Water {
    public static void main(String[] args) {
        Solver solve = new Solver();
        if (args.length < 2) {
            System.out.println(("Usage: java Water amount bucket1 bucket2 ..."));
        } else {
            System.out.print("Amount: " + args[0]+", ");
            ArrayList<Integer> buckets = new ArrayList<>();
            for (int i = 1; i < args.length; ++i) {
                buckets.add(Integer.parseInt(args[i]));
            }
            System.out.println("Buckets: " + buckets);
            WaterConfig waterConfig = new WaterConfig(Integer.parseInt(args[0]),buckets);
            ArrayList<Configuration> path = solve.solve(waterConfig);
            System.out.println("Total configs: " + solve.getTotalConfigs());
            System.out.println("Unique configs: " + solve.getUniqueConfigs());
            if (path.isEmpty()) {
                System.out.println("No solution");
            } else {
                int step = 0;
                for (Configuration i : path) {
                    System.out.println("Step " + step + ": " + i.toString());
                    step += 1;
                }
            }
        }
    }


}

